import seriesData from "../api/seriesData.json";
const Netflix = () => {
    return (
      <div>
        <div>
        <img
          href={seriesData[0].img_url}
          alt="Poster"
          className="Netflix-poster"
        /></div>
        <h3>Name:{seriesData[0].name} </h3>
        <h4>Rating:{seriesData[0].rating}</h4>
       <p>Summary:{seriesData[0].description}</p>
       <p>Genre:{seriesData[0].genre}</p>
       <p>Cast:{seriesData[0].cast}</p>
       <a href={seriesData[0].watch_url} target="_blank">
       <button>Watch Now</button>
       </a>
       {/* Solution:2 */}
       {/* <button> {age>= 18 ? "Watch Now" : "Not Available"}</button> */}
       {/* Solution:3 */}
       {/* <button>{canWatch}</button> */}
      </div>
    );
  };
 
export default Netflix;
  