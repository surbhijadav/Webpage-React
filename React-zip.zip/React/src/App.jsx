
import Netflix from "./components/Netflix";

export const App = () => {
  return (
    <>
      <Netflix />
      
    </>
  );
};

